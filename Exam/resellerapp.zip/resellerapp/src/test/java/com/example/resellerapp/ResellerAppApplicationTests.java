package com.example.resellerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResellerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
