package com.example.resellerapp.service;

import org.springframework.stereotype.Service;

@Service
public class ConditionService {
}
